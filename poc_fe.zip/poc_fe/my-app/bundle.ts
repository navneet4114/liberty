const fs = require('fs');
const archiver = require('archiver');
const rimraf = require("rimraf");

var dir = './dist';

if (!fs.existsSync(dir)){
    fs.mkdirSync(dir);
}

// 1
const out = 'dist/build.war';

// 2
const output = fs.createWriteStream(out);

const archive = archiver('zip', {});

output.on('close', function() {
    console.log(archive.pointer() + ' total bytes');
    console.log('archiver has been finalized and the output file descriptor has closed.');
});

archive.on('error', function(err) {
    throw err;
});

archive.pipe(output);

// 5
//archive.directory('build/', true, { date: new Date() });
archive.glob("build/**/*");

// 6
archive.finalize();