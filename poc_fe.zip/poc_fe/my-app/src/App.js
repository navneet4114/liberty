import React, { Component } from 'react';
import axios from 'axios';
import logo from './logo.svg';
import './App.css';

class App extends Component {
  state = {
    apiOutput: ""
  }

  componentDidMount() {
    axios.get(`http://54.198.170.124:9084/app/hello`)
      .then(res => {
        const apiOutput = res.data;
        this.setState({ apiOutput });
      });
  }

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <p className="bg-dark text-white">
            {this.state.apiOutput}
          </p>
        </header>
      </div>
    )
  }
  
}

export default App;
